const Mera = require('./mera.model');
const Ayarlar = require('../ayarlar/ayarlar.model');
const { google } = require('googleapis');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Görsel ve PDF limitler
const GORSEL_MAX_W = 1920;
const GORSEL_MAX_H = 1920;
const GORSEL_KALITE = 85;
const PDF_MAX_MB = 20;

let sharp;
try { sharp = require('sharp'); } catch { sharp = null; }

// Görsel sıkıştır
const gorselSikistir = async (buffer, mimeType) => {
  if (!sharp) return buffer;
  const goruntuMime = ['image/jpeg','image/jpg','image/png','image/webp'];
  if (!goruntuMime.includes(mimeType)) return buffer;
  try {
    return await sharp(buffer)
      .resize(GORSEL_MAX_W, GORSEL_MAX_H, { fit: 'inside', withoutEnlargement: true })
      .jpeg({ quality: GORSEL_KALITE })
      .toBuffer();
  } catch { return buffer; }
};

// ── Drive yardımcı ────────────────────────────────────────
const getDriveClient = async () => {
  const ayarlar = await Ayarlar.findOne();
  const hesap = ayarlar?.drive_hesaplari?.find(h => h.aktif && h.yetkili);
  if (!hesap) throw new Error('NO_DRIVE'); // Caller lokal fallback kullanır

  if (hesap.tip === 'oauth2') {
    if (!hesap.oauth_token) throw new Error('NO_DRIVE');
    const { client_id, client_secret } = hesap.oauth_client_json.installed || hesap.oauth_client_json.web;
    const oauth2 = new google.auth.OAuth2(client_id, client_secret, 'urn:ietf:wg:oauth:2.0:oob');
    oauth2.setCredentials(hesap.oauth_token);
    oauth2.on('tokens', async (tokens) => {
      const guncellenen = { ...hesap.oauth_token, ...tokens };
      await Ayarlar.updateOne({ 'drive_hesaplari._id': hesap._id }, { $set: { 'drive_hesaplari.$.oauth_token': guncellenen } });
    });
    return { drive: google.drive({ version: 'v3', auth: oauth2 }), hesap };
  }

  const auth = new google.auth.GoogleAuth({
    credentials: hesap.service_account_json,
    scopes: ['https://www.googleapis.com/auth/drive'],
  });
  return { drive: google.drive({ version: 'v3', auth }), hesap };
};

const getMisDriveFolder = async (drive, altKlasor) => {
  const misRes = await drive.files.list({
    q: `name='MİS' and mimeType='application/vnd.google-apps.folder' and trashed=false`,
    fields: 'files(id,name)',
  });
  if (!misRes.data.files.length) throw new Error("Drive'da 'MİS' klasörü bulunamadı.");
  let parentId = misRes.data.files[0].id;

  for (const klasor of altKlasor) {
    const res = await drive.files.list({
      q: `name='${klasor}' and '${parentId}' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false`,
      fields: 'files(id)',
    });
    if (res.data.files.length) {
      parentId = res.data.files[0].id;
    } else {
      const yeni = await drive.files.create({
        requestBody: { name: klasor, mimeType: 'application/vnd.google-apps.folder', parents: [parentId] },
        fields: 'id',
      });
      parentId = yeni.data.id;
    }
  }
  return parentId;
};

const driveYukle = async (drive, folderId, dosyaAdi, mimeType, buffer) => {
  const { Readable } = require('stream');
  const stream = new Readable();
  stream.push(buffer);
  stream.push(null);
  const res = await drive.files.create({
    requestBody: { name: dosyaAdi, parents: [folderId] },
    media: { mimeType, body: stream },
    fields: 'id,webViewLink,webContentLink',
  });
  await drive.permissions.create({
    fileId: res.data.id,
    requestBody: { role: 'reader', type: 'anyone' },
  });
  return res.data;
};

// ── Sunucu lokal depolama (Drive yoksa) ──────────────────
const lokalYukle = async (mera, dosyaAdi, buffer) => {
  const fs   = require('fs');
  const path = require('path');
  const dir  = path.join(__dirname, '../../uploads/kml', String(mera.il_ad||'genel'));
  fs.mkdirSync(dir, { recursive: true });
  const dosyaYolu = path.join(dir, dosyaAdi);
  fs.writeFileSync(dosyaYolu, buffer);
  const lokal_path = `/uploads/kml/${mera.il_ad||'genel'}/${dosyaAdi}`;
  return { id: null, webViewLink: lokal_path, lokal: true, lokal_path };
};

// ── Otlatma kapasitesi hesapla ────────────────────────────
const hesaplaOtlatma = async (il_id, vasif, alan_da) => {
  const ayarlar = await Ayarlar.findOne();
  if (!ayarlar) return null;
  const kusak = ayarlar.yagis_kusaklari?.find(y => y.il_id === String(il_id))?.kusak;
  if (!kusak || !alan_da) return null;

  // Bilinmiyor veya boş → Orta vasıf olarak hesapla
  const vasifEtkin = (!vasif || vasif === 'Bilinmiyor') ? 'Orta' : vasif;
  const vasifKey = { 'Çok İyi': 'cok_iyi', 'İyi': 'iyi', 'Orta': 'orta', 'Zayıf': 'zayif' }[vasifEtkin];
  if (!vasifKey) return null;
  const t1 = ayarlar.yararlanilabilir_yesil_ot?.find(r => r.kusak === kusak);
  const t2 = ayarlar.uretilen_yesil_ot?.find(r => r.kusak === kusak);
  const t3 = ayarlar.uretilen_kuru_ot?.find(r => r.kusak === kusak);
  if (!t1 || !t2 || !t3) return null;

  const yyo_kg = parseFloat((t1[vasifKey] * alan_da).toFixed(2));
  const uyo_kg = parseFloat((t2[vasifKey] * alan_da).toFixed(2));
  const uko_kg = parseFloat((t3[vasifKey] * alan_da).toFixed(2));
  const kapasite = parseFloat((yyo_kg / 50 / 180).toFixed(4));

  return {
    kusak, vasif, alan_da,
    yararlanilabilir_yesil_ot_kg: yyo_kg,
    yararlanilabilir_yesil_ot_ton: parseFloat((yyo_kg / 1000).toFixed(3)),
    uretilen_yesil_ot_kg: uyo_kg,
    uretilen_yesil_ot_ton: parseFloat((uyo_kg / 1000).toFixed(3)),
    uretilen_kuru_ot_kg: uko_kg,
    uretilen_kuru_ot_ton: parseFloat((uko_kg / 1000).toFixed(3)),
    otlatma_kapasitesi_bbhb: kapasite,
    hayvan_sayisi_180gun: Math.floor(kapasite),
    hesaplama_tarihi: new Date(),
  };
};

// ── CRUD ──────────────────────────────────────────────────
const listele = async (req, res, next) => {
  try {
    const { il_id, ilce_id, mahalle_id, durum, ara, sayfa = 1, limit = 20 } = req.query;
    const filtre = {};
    if (il_id) filtre.il_id = il_id;
    if (ilce_id) filtre.ilce_id = ilce_id;
    if (mahalle_id) filtre.mahalle_id = mahalle_id;
    if (durum) filtre.durum = durum;
    if (ara) filtre.$or = [
      { ada: new RegExp(ara, 'i') },
      { parsel: new RegExp(ara, 'i') },
      { mahalle_ad: new RegExp(ara, 'i') },
      { nitelik: new RegExp(ara, 'i') },
    ];
    const toplam = await Mera.countDocuments(filtre);
    const meralar = await Mera.find(filtre)
      .sort({ createdAt: -1 })
      .skip((sayfa - 1) * limit)
      .limit(parseInt(limit))
      .select('-notlar -dosyalar -kml_koordinatlar');
    res.json({ success: true, toplam, sayfa: parseInt(sayfa), limit: parseInt(limit), data: meralar });
  } catch (err) { next(err); }
};

const getById = async (req, res, next) => {
  try {
    const mera = await Mera.findById(req.params.id);
    if (!mera) return res.status(404).json({ success: false, message: 'Mera bulunamadı' });
    res.json({ success: true, data: mera });
  } catch (err) { next(err); }
};

const olustur = async (req, res, next) => {
  try {
    const { il_id, il_ad, ilce_id, ilce_ad, mahalle_id, mahalle_ad, ada, parsel,
      tapu_alani_da, tespit_alani_da, nitelik, vasif, toprak_sinifi, durum, aciklama } = req.body;

    const ayarlar = await Ayarlar.findOne();
    const toprakBilgi = ayarlar?.toprak_siniflari?.find(t => t.sinif === toprak_sinifi);

    // Otlatma hesabı için önce tapu, yoksa tespit alanını kullan
    const hesapAlani = parseFloat(tapu_alani_da) || parseFloat(tespit_alani_da) || 0;
    const otlatma = hesapAlani && il_id
      ? await hesaplaOtlatma(il_id, vasif, hesapAlani)
      : null;

    const mera = await Mera.create({
      il_id, il_ad, ilce_id, ilce_ad, mahalle_id, mahalle_ad,
      ada, parsel,
      tapu_alani_da:   tapu_alani_da   !== undefined ? (parseFloat(tapu_alani_da)   || null) : null,
      tespit_alani_da: tespit_alani_da !== undefined ? (parseFloat(tespit_alani_da) || null) : null,
      nitelik, vasif, toprak_sinifi,
      toprak_sinifi_tanim: toprakBilgi?.tanim || '',
      durum: durum || 'Aktif', aciklama, otlatma,
    });
    res.status(201).json({ success: true, data: mera });
  } catch (err) { next(err); }
};

const guncelle = async (req, res, next) => {
  try {
    const mera = await Mera.findById(req.params.id);
    if (!mera) return res.status(404).json({ success: false, message: 'Mera bulunamadı' });
    const guncellenecek = ['il_id','il_ad','ilce_id','ilce_ad','mahalle_id','mahalle_ad',
      'ada','parsel','tapu_alani_da','tespit_alani_da','kadastral_alan_da',
      'nitelik','vasif','toprak_sinifi','durum','aciklama','kaynak'];
    guncellenecek.forEach(alan => { if (req.body[alan] !== undefined) mera[alan] = req.body[alan]; });
    if (req.body.mulkiyet !== undefined) mera.mulkiyet = { ...mera.mulkiyet?.toObject?.() || {}, ...req.body.mulkiyet };

    const ayarlar = await Ayarlar.findOne();
    if (req.body.toprak_sinifi) {
      const tb = ayarlar?.toprak_siniflari?.find(t => t.sinif === req.body.toprak_sinifi);
      mera.toprak_sinifi_tanim = tb?.tanim || '';
    }
    if (req.body.vasif || req.body.tapu_alani_da || req.body.tespit_alani_da) {
      const hesapAlani = mera.tapu_alani_da || mera.tespit_alani_da;
      mera.otlatma = await hesaplaOtlatma(mera.il_id, mera.vasif, hesapAlani) || mera.otlatma;
    }
    await mera.save();
    res.json({ success: true, data: mera });
  } catch (err) { next(err); }
};

const sil = async (req, res, next) => {
  try {
    await Mera.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Mera silindi' });
  } catch (err) { next(err); }
};

// ── KML Yükleme ───────────────────────────────────────────
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

const kmlYukle = async (req, res, next) => {
  try {
    const mera = await Mera.findById(req.params.id);
    if (!mera) return res.status(404).json({ success: false, message: 'Mera bulunamadı' });
    if (!req.file) return res.status(400).json({ success: false, message: 'Dosya seçin' });

    let kmlBuffer;
    const orijinalAd = req.file.originalname.toLowerCase();

    // ── GeoJSON → KML dönüşümü ─────────────────────────
    if (orijinalAd.endsWith('.geojson') || orijinalAd.endsWith('.json')) {
      const geojson = JSON.parse(req.file.buffer.toString('utf-8'));
      kmlBuffer = Buffer.from(geojsonToKml(geojson, mera), 'utf-8');

    // ── KMZ açma ───────────────────────────────────────
    } else if (orijinalAd.endsWith('.kmz')) {
      const JSZip = require('jszip');
      const zip = await JSZip.loadAsync(req.file.buffer);
      const kmlFile = Object.keys(zip.files).find(f => f.endsWith('.kml'));
      if (!kmlFile) return res.status(400).json({ success: false, message: 'KMZ içinde KML bulunamadı' });
      kmlBuffer = Buffer.from(await zip.files[kmlFile].async('arraybuffer'));

    // ── Ham KML ────────────────────────────────────────
    } else {
      kmlBuffer = req.file.buffer;
    }

    // Namespace fix
    let kmlStr = kmlBuffer.toString('utf-8');
    if (!kmlStr.startsWith('<?xml')) kmlStr = '<?xml version="1.0" encoding="UTF-8"?>\n' + kmlStr;
    if (!kmlStr.includes('xmlns="http://www.opengis.net/kml/2.2"')) {
      kmlStr = kmlStr.replace(/<kml([^>]*)>/, (m, a) =>
        a.includes('xmlns') ? m : `<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2"${a}>`
      );
    }
    kmlBuffer = Buffer.from(kmlStr, 'utf-8');

    const tarihStr = new Date().toISOString().slice(0,10).replace(/-/g,'');
    const surum = Math.random().toString(36).slice(2,6).toUpperCase();
    const temizle = (s) => (s||'').replace(/\s+/g,'-').replace(/[^a-zA-Z0-9\-_ğüşıöçĞÜŞİÖÇ]/g,'');
    const dosyaAdi = `${temizle(mera.il_ad)}-${temizle(mera.ilce_ad)}-${temizle(mera.mahalle_ad)}-${mera.ada||'0'}-${mera.parsel}-${tarihStr}-${surum}.kml`;

    // ── Drive'a yükle (yoksa lokale) ───────────────────
    let driveData;
    let depolama = 'drive';

    try {
      const { drive } = await getDriveClient();
      const folderId = await getMisDriveFolder(drive, [mera.il_ad, mera.ilce_ad, mera.mahalle_ad, `${mera.ada||'0'}-${mera.parsel}`, 'KML']);
      driveData = await driveYukle(drive, folderId, dosyaAdi, 'application/vnd.google-earth.kml+xml', kmlBuffer);
    } catch (driveErr) {
      // Drive hatası (invalid_grant, token süresi vb.) → lokale düş
      console.warn('[KML] Drive hatası, lokale kaydediliyor:', driveErr.message);
      driveData = await lokalYukle(mera, dosyaAdi, kmlBuffer);
      depolama = 'lokal';
    }

    const downloadLink = driveData.id
      ? `https://drive.google.com/uc?export=download&id=${driveData.id}`
      : driveData.lokal_path;

    // Eski KML'i geçmişe al
    if (mera.kml_drive_file_id) {
      mera.kml_gecmis.push({
        drive_file_id: mera.kml_drive_file_id,
        drive_web_link: mera.kml_drive_web_link,
        drive_download_link: mera.kml_drive_download_link,
        dosya_adi: `önceki-${mera.kml_gecmis.length + 1}`,
        surum,
      });
    }

    mera.kml_drive_file_id       = driveData.id || dosyaAdi;
    mera.kml_drive_web_link      = driveData.webViewLink;
    mera.kml_drive_download_link = downloadLink;

    mera.dosyalar.push({
      ad: dosyaAdi,
      kategori: 'KML Dosyası',
      kaynak: 'kml',
      drive_file_id: driveData.id || null,
      drive_web_link: driveData.webViewLink,
      drive_download_link: downloadLink,
      boyut: kmlBuffer.length,
      mime_type: 'application/vnd.google-earth.kml+xml',
    });

    await mera.save();
    res.json({
      success: true,
      depolama,
      uyari: depolama === 'lokal' ? 'Drive bağlantısı kurulamadı, dosya sunucuya kaydedildi. Ayarlar > Depolama Alanı üzerinden Drive hesabınızı yeniden yetkilendirin.' : null,
      data: { file_id: driveData.id, web_link: driveData.webViewLink, download_link: downloadLink, dosya_adi: dosyaAdi },
    });
  } catch (err) { next(err); }
};

// ── GeoJSON → KML dönüştürücü ────────────────────────────
const geojsonToKml = (geojson, mera) => {
  const ad = `${mera.il_ad||''} ${mera.ilce_ad||''} ${mera.ada||''}-${mera.parsel||''}`.trim();
  const coordsToKml = (coords) => coords.map(c => c.join(',')).join(' ');

  const featureToPlacemark = (feature, idx) => {
    const name = feature.properties?.name || feature.properties?.ad || `Parsel ${idx+1}`;
    const desc = feature.properties?.description || feature.properties?.aciklama || '';
    const geom = feature.geometry;
    let geomKml = '';

    if (geom.type === 'Polygon') {
      const outer = coordsToKml(geom.coordinates[0]);
      const inner = geom.coordinates.slice(1).map(r =>
        `<innerBoundaryIs><LinearRing><coordinates>${coordsToKml(r)}</coordinates></LinearRing></innerBoundaryIs>`
      ).join('');
      geomKml = `<Polygon><outerBoundaryIs><LinearRing><coordinates>${outer}</coordinates></LinearRing></outerBoundaryIs>${inner}</Polygon>`;
    } else if (geom.type === 'MultiPolygon') {
      geomKml = `<MultiGeometry>${geom.coordinates.map(poly => {
        const outer = coordsToKml(poly[0]);
        return `<Polygon><outerBoundaryIs><LinearRing><coordinates>${outer}</coordinates></LinearRing></outerBoundaryIs></Polygon>`;
      }).join('')}</MultiGeometry>`;
    } else if (geom.type === 'Point') {
      geomKml = `<Point><coordinates>${geom.coordinates.join(',')}</coordinates></Point>`;
    } else if (geom.type === 'LineString') {
      geomKml = `<LineString><coordinates>${coordsToKml(geom.coordinates)}</coordinates></LineString>`;
    }

    return `<Placemark><name>${name}</name><description>${desc}</description>${geomKml}</Placemark>`;
  };

  const features = geojson.type === 'FeatureCollection'
    ? geojson.features
    : geojson.type === 'Feature'
      ? [geojson]
      : [{ type: 'Feature', geometry: geojson, properties: {} }];

  const placemarks = features.map((f, i) => featureToPlacemark(f, i)).join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2">
  <Document>
    <name>${ad}</name>
    <Style id="mera"><LineStyle><color>ff0f6e56</color><width>2</width></LineStyle><PolyStyle><color>800f6e56</color></PolyStyle></Style>
    ${placemarks}
  </Document>
</kml>`;
};

const kmlGetir = async (req, res, next) => {
  try {
    const mera = await Mera.findById(req.params.id).select('kml_drive_file_id kml_drive_download_link il_ad ilce_ad mahalle_ad ada parsel');
    if (!mera?.kml_drive_file_id) return res.status(404).json({ success: false, message: 'KML bulunamadı' });

    // Lokal dosya mı?
    if (!mera.kml_drive_file_id.startsWith('1') || mera.kml_drive_download_link?.startsWith('/uploads')) {
      const fs   = require('fs');
      const path = require('path');
      const lokal = path.join(__dirname, '../../uploads/kml', mera.il_ad||'genel', mera.kml_drive_file_id);
      if (fs.existsSync(lokal)) {
        const buf = fs.readFileSync(lokal);
        res.setHeader('Content-Type', 'application/vnd.google-earth.kml+xml; charset=UTF-8');
        res.setHeader('Content-Disposition', `attachment; filename="${mera.kml_drive_file_id}"`);
        return res.send(buf);
      }
    }

    const { drive } = await getDriveClient();
    const response = await drive.files.get({ fileId: mera.kml_drive_file_id, alt: 'media' }, { responseType: 'arraybuffer' });
    let kmlStr = Buffer.from(response.data).toString('utf-8');

    if (!kmlStr.includes('xmlns="http://www.opengis.net/kml/2.2"')) {
      kmlStr = kmlStr.replace(/<kml([^>]*)>/, (match, attrs) => {
        if (attrs.includes('xmlns')) return match;
        return `<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2"${attrs}>`;
      });
    }
    if (!kmlStr.startsWith('<?xml')) kmlStr = '<?xml version="1.0" encoding="UTF-8"?>\n' + kmlStr;

    const dosyaAdi = `${mera.il_ad||'mera'}-${mera.ada||'0'}-${mera.parsel||'0'}.kml`;
    res.setHeader('Content-Type', 'application/vnd.google-earth.kml+xml; charset=UTF-8');
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(dosyaAdi)}"`);
    res.send(Buffer.from(kmlStr, 'utf-8'));
  } catch (err) { next(err); }
};

// ── Not CRUD ──────────────────────────────────────────────
const notEkle = async (req, res, next) => {
  try {
    const mera = await Mera.findById(req.params.id);
    if (!mera) return res.status(404).json({ success: false, message: 'Mera bulunamadı' });
    const { icerik, renk, renk_adi, metin_rengi, dosya_id } = req.body;

    const notVerisi = {
      icerik,
      renk: renk || '#0d6efd',
      renk_adi: renk_adi || 'Bilgi',
      metin_rengi: metin_rengi || '#fff',
    };

    // Dosya yükleme varsa Drive'a at
    if (req.file) {
      const { drive } = await getDriveClient();
      const tarihStr = new Date().toISOString().slice(0,10).replace(/-/g,'');
      const surum = Math.random().toString(36).slice(2,6).toUpperCase();
      const dosyaAdi = `${tarihStr}-not-eki-${surum}${path.extname(req.file.originalname)}`;
      const folderId = await getMisDriveFolder(drive, [mera.il_ad, mera.ilce_ad, mera.mahalle_ad, `${mera.ada||'0'}-${mera.parsel}`, 'Notlar']);
      const driveData = await driveYukle(drive, folderId, dosyaAdi, req.file.mimetype, req.file.buffer);
      const downloadLink = `https://drive.google.com/uc?export=download&id=${driveData.id}`;

      // Dosyalar listesine ekle
      mera.dosyalar.push({
        ad: dosyaAdi,
        kategori: 'Not Eki',
        kaynak: 'dosyalar',
        drive_file_id: driveData.id,
        drive_web_link: driveData.webViewLink,
        drive_download_link: downloadLink,
        boyut: req.file.buffer.length,
        mime_type: req.file.mimetype,
        not_icerik: icerik,
      });
      notVerisi.dosya_id = mera.dosyalar[mera.dosyalar.length - 1]._id;
    } else if (dosya_id) {
      // Mevcut dosyadan seçim
      notVerisi.dosya_id = dosya_id;
    }

    mera.notlar.push(notVerisi);
    await mera.save();
    res.json({ success: true, data: mera.notlar[mera.notlar.length - 1] });
  } catch (err) { next(err); }
};

const notGuncelle = async (req, res, next) => {
  try {
    const mera = await Mera.findById(req.params.id);
    if (!mera) return res.status(404).json({ success: false, message: 'Mera bulunamadı' });
    const not = mera.notlar.id(req.params.notId);
    if (!not) return res.status(404).json({ success: false, message: 'Not bulunamadı' });
    // Eski içeriği logla
    not.duzenlemeler.push({ eski_icerik: not.icerik });
    not.icerik = req.body.icerik || not.icerik;
    if (req.body.renk) { not.renk = req.body.renk; not.renk_adi = req.body.renk_adi; not.metin_rengi = req.body.metin_rengi; }
    await mera.save();
    res.json({ success: true, data: not });
  } catch (err) { next(err); }
};

const notSil = async (req, res, next) => {
  try {
    const mera = await Mera.findById(req.params.id);
    if (!mera) return res.status(404).json({ success: false, message: 'Mera bulunamadı' });
    const not = mera.notlar.id(req.params.notId);
    if (!not) return res.status(404).json({ success: false, message: 'Not bulunamadı' });
    // Silmeyi logla
    not.duzenlemeler.push({ eski_icerik: not.icerik });
    not.icerik = '[SİLİNDİ]';
    await mera.save();
    res.json({ success: true, message: 'Not silindi (log tutuldu)' });
  } catch (err) { next(err); }
};

// ── Dosya Yükleme ─────────────────────────────────────────
const dosyaYukle = async (req, res, next) => {
  try {
    const mera = await Mera.findById(req.params.id);
    if (!mera) return res.status(404).json({ success: false, message: 'Mera bulunamadı' });
    if (!req.file) return res.status(400).json({ success: false, message: 'Dosya seçin' });

    // PDF boyut kontrolü
    if (req.file.mimetype === 'application/pdf') {
      const mbCinsinden = req.file.size / 1024 / 1024;
      if (mbCinsinden > PDF_MAX_MB) {
        return res.status(400).json({ success: false, message: `PDF maksimum ${PDF_MAX_MB}MB olabilir (${mbCinsinden.toFixed(1)}MB)` });
      }
    }

    const { kategori, ad, not_icerik } = req.body;
    const tarih = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const surum = Math.random().toString(36).slice(2,6).toUpperCase();
    const dosyaAdi = `${tarih}-${(kategori || 'diger').replace(/\s/g,'-')}-${ad || surum}`;
    const ext = path.extname(req.file.originalname);
    const temizAd = dosyaAdi.endsWith(ext) ? dosyaAdi : dosyaAdi + ext;

    let buffer = req.file.buffer;
    let mimeType = req.file.mimetype;
    const goruntuMime = ['image/jpeg','image/jpg','image/png','image/webp'];
    if (goruntuMime.includes(mimeType)) {
      buffer = await gorselSikistir(buffer, mimeType);
      mimeType = 'image/jpeg';
    }

    const { drive } = await getDriveClient();
    const folderId = await getMisDriveFolder(drive, [
      mera.il_ad, mera.ilce_ad, mera.mahalle_ad,
      `${mera.ada || '0'}-${mera.parsel}`, kategori || 'Diger'
    ]);
    const driveData = await driveYukle(drive, folderId, temizAd, mimeType, buffer);
    const downloadLink = `https://drive.google.com/uc?export=download&id=${driveData.id}`;

    mera.dosyalar.push({
      ad: temizAd, kategori,
      kaynak: 'dosyalar',
      drive_file_id: driveData.id,
      drive_web_link: driveData.webViewLink,
      drive_download_link: downloadLink,
      boyut: buffer.length,
      mime_type: mimeType,
      not_icerik: not_icerik || '',
    });

    // Not ekleme
    if (not_icerik) {
      const { renk, renk_adi, metin_rengi } = req.body;
      mera.notlar.push({
        icerik: not_icerik,
        renk: renk || '#0d6efd',
        renk_adi: renk_adi || 'Bilgi',
        metin_rengi: metin_rengi || '#fff',
        dosya_id: mera.dosyalar[mera.dosyalar.length - 1]._id,
      });
    }

    await mera.save();
    res.json({ success: true, data: mera.dosyalar[mera.dosyalar.length - 1] });
  } catch (err) { next(err); }
};

const dosyaSil = async (req, res, next) => {
  try {
    const mera = await Mera.findById(req.params.id);
    const dosya = mera?.dosyalar?.id(req.params.dosyaId);
    if (!dosya) return res.status(404).json({ success: false, message: 'Dosya bulunamadı' });
    try {
      const { drive } = await getDriveClient();
      await drive.files.delete({ fileId: dosya.drive_file_id });
    } catch {}
    dosya.deleteOne();
    await mera.save();
    res.json({ success: true, message: 'Dosya silindi' });
  } catch (err) { next(err); }
};

// ── Rapor ─────────────────────────────────────────────────
const pdfRapor = async (req, res, next) => {
  try {
    const mera = await Mera.findById(req.params.id);
    if (!mera) return res.status(404).json({ success: false, message: 'Mera bulunamadı' });

    const o = mera.otlatma;
    const m = mera.mulkiyet || {};
    const fmt = (n) => n != null ? Number(n).toLocaleString('tr-TR') : '-';

    const baslik = `${mera.il_ad} / ${mera.ilce_ad} / ${mera.mahalle_ad} — Ada: ${mera.ada||'-'} Parsel: ${mera.parsel}`;

    const sayfaBasligi = `
      <div class="sayfa-baslik">
        <strong>MERA PARSEL RAPORU</strong>
        <span class="kucuk">${baslik}</span>
      </div>`;

    const html = `<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8"/>
  <title>Mera Raporu - ${baslik}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;600;700&display=swap');
    *{margin:0;padding:0;box-sizing:border-box;}
    body{font-family:'Noto Sans',Arial,sans-serif;font-size:10pt;color:#222;padding:12mm 15mm;}
    .sayfa-baslik{border-bottom:2px solid #0F6E56;padding-bottom:3mm;margin-bottom:4mm;display:flex;justify-content:space-between;align-items:flex-end;}
    .sayfa-baslik strong{font-size:13pt;color:#0F6E56;}
    .sayfa-baslik .kucuk{font-size:9pt;color:#666;}
    h2{font-size:11pt;color:#0F6E56;margin:5mm 0 2mm;border-bottom:1px solid #9FE1CB;padding-bottom:1mm;}
    table{width:100%;border-collapse:collapse;margin-bottom:3mm;font-size:9.5pt;}
    th{background:#0F6E56;color:#fff;padding:3pt 7pt;text-align:left;font-size:9pt;}
    td{padding:3pt 7pt;border-bottom:1px solid #eee;vertical-align:top;}
    .label{color:#555;width:28%;font-size:9pt;}
    .val{font-weight:500;}
    .badge{display:inline-block;padding:1px 8px;border-radius:10px;font-size:8.5pt;}
    .footer{margin-top:6mm;font-size:8.5pt;color:#aaa;text-align:center;border-top:1px solid #ddd;padding-top:2mm;}
    .print-btn{text-align:center;margin-bottom:6mm;}
    @media print{
      .print-btn{display:none;}
      .sayfa-kirici{page-break-before:always;}
      .sayfa-baslik{display:flex!important;}
    }
  </style>
</head>
<body>
  <div class="print-btn">
    <button onclick="window.print()" style="background:#0F6E56;color:#fff;border:none;padding:7px 22px;border-radius:6px;font-size:11pt;cursor:pointer;">PDF Olarak Yazdır / Kaydet</button>
  </div>

  ${sayfaBasligi}

  <h2>Mera Bilgileri</h2>
  <table><tbody>
    <tr><td class="label">İl</td><td class="val">${mera.il_ad}</td><td class="label">İlçe</td><td class="val">${mera.ilce_ad}</td></tr>
    <tr><td class="label">Mahalle/Köy</td><td class="val">${mera.mahalle_ad}</td><td class="label">Ada / Parsel</td><td class="val">${mera.ada||'-'} / ${mera.parsel}</td></tr>
    <tr><td class="label">Tapu Alanı</td><td class="val">${fmt(mera.tapu_alani_da)} da</td><td class="label">Kadastral Alan</td><td class="val">${mera.kadastral_alan_da ? fmt(mera.kadastral_alan_da)+' da' : '-'}</td></tr>
    <tr><td class="label">Nitelik</td><td class="val">${mera.nitelik||'-'}</td><td class="label">Durum</td><td class="val">${mera.durum}</td></tr>
    <tr><td class="label">Vasıf</td><td class="val">${mera.vasif||'-'}${mera.vasif_bitis?` (${new Date(mera.vasif_bitis).toLocaleDateString('tr-TR')} bitiş)`:''}</td><td class="label">Toprak Sınıfı</td><td class="val">${mera.toprak_sinifi||'-'}</td></tr>
    <tr><td class="label">Tahsis Durumu</td><td class="val">${mera.tahsis_durumu||'-'}${mera.tahsis_durumu_bitis?` (${new Date(mera.tahsis_durumu_bitis).toLocaleDateString('tr-TR')} bitiş)`:''}</td><td class="label">KML Haritası</td><td class="val">${mera.kml_drive_file_id ? '✓ Yüklü' : '✗ Yüklenmemiş'}</td></tr>
  </tbody></table>

  ${(m.malik || m.cilt_no) ? `
  <h2>Mülkiyet Bilgileri (Tapu Kaydı)</h2>
  <table><tbody>
    <tr><td class="label">Cilt No</td><td class="val">${m.cilt_no||'-'}</td><td class="label">Sayfa No</td><td class="val">${m.sayfa_no||'-'}</td></tr>
    <tr><td class="label">Kayıt Durumu</td><td class="val">${m.kayit_durum||'-'}</td><td class="label">Pay / Payda</td><td class="val">${m.pay||'-'} / ${m.payda||'-'}</td></tr>
    <tr><td class="label">Malik</td><td class="val" colspan="3">${m.malik||'-'}</td></tr>
    ${m.serhler ? `<tr><td class="label">Şerhler</td><td class="val" colspan="3">${m.serhler}</td></tr>` : ''}
  </tbody></table>` : ''}

  ${o ? `
  <h2>Otlatma Kapasitesi</h2>
  <table><tbody>
    <tr><td class="label">Yağış Kuşağı</td><td class="val">${o.kusak} mm</td><td class="label">Vasıf</td><td class="val">${o.vasif}</td></tr>
    <tr><td class="label">Alan</td><td class="val">${fmt(o.alan_da)} da</td><td class="label">Otlatma Kap.</td><td class="val">${fmt(o.otlatma_kapasitesi_bbhb)} BBHB</td></tr>
    <tr><td class="label">180 Gün Hayvan</td><td class="val">${fmt(o.hayvan_sayisi_180gun)} baş</td><td class="label"></td><td></td></tr>
    <tr><td class="label">Yar. Yeşil Ot</td><td class="val">${fmt(o.yararlanilabilir_yesil_ot_ton)} ton (${fmt(o.yararlanilabilir_yesil_ot_kg)} kg)</td>
        <td class="label">Üretilen Yeşil Ot</td><td class="val">${fmt(o.uretilen_yesil_ot_ton)} ton</td></tr>
    <tr><td class="label">Üretilen Kuru Ot</td><td class="val">${fmt(o.uretilen_kuru_ot_ton)} ton (${fmt(o.uretilen_kuru_ot_kg)} kg)</td><td></td><td></td></tr>
  </tbody></table>` : ''}

  ${mera.notlar?.filter(n=>n.icerik!=='[SİLİNDİ]').length ? `
  <div class="sayfa-kirici"></div>
  ${sayfaBasligi}
  <h2>Notlar</h2>
  <table>
    <thead><tr><th style="width:25%">Tarih</th><th style="width:12%">Tür</th><th>İçerik</th></tr></thead>
    <tbody>
    ${mera.notlar.filter(n=>n.icerik!=='[SİLİNDİ]').map(n=>`
    <tr><td style="font-size:8.5pt;color:#666">${new Date(n.createdAt).toLocaleString('tr-TR')}</td>
    <td><span class="badge" style="background:${n.renk};color:${n.metin_rengi}">${n.renk_adi}</span></td>
    <td>${n.icerik}</td></tr>`).join('')}
    </tbody>
  </table>` : ''}

  ${mera.dosyalar?.length ? `
  <h2>Yüklü Dosyalar</h2>
  <table>
    <thead><tr><th>Dosya Adı</th><th style="width:20%">Kategori</th><th style="width:15%">Kaynak</th><th style="width:20%">Tarih</th></tr></thead>
    <tbody>
    ${mera.dosyalar.map(d=>{
      const kaynakMap = {kml:'KML',vasif:'Vasıf',tahsis:'Tahsis',dosyalar:'Genel'};
      return `<tr>
        <td style="font-size:8.5pt">${d.ad}</td>
        <td style="font-size:8.5pt">${d.kategori||'-'}</td>
        <td style="font-size:8.5pt">${kaynakMap[d.kaynak]||'-'}</td>
        <td style="font-size:8.5pt">${new Date(d.yukleme_tarihi||d.createdAt).toLocaleDateString('tr-TR')}</td>
      </tr>`;
    }).join('')}
    </tbody>
  </table>` : ''}

  <div class="footer">MİS - Mera İzleme Sistemi &nbsp;|&nbsp; Rapor Tarihi: ${new Date().toLocaleString('tr-TR')}</div>
</body></html>`;

    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(html);
  } catch (err) { next(err); }
};

// ── Vasıf Dosya Yükleme ───────────────────────────────────
const vasifDosyaYukle = async (req, res, next) => {
  try {
    const mera = await Mera.findById(req.params.id);
    if (!mera) return res.status(404).json({ success: false, message: 'Mera bulunamadı' });
    if (!req.file) return res.status(400).json({ success: false, message: 'Dosya seçin' });
    const { vasif, tarih } = req.body;
    if (!tarih) return res.status(400).json({ success: false, message: 'Tarih zorunlu' });

    const tarihObj = new Date(tarih);
    const bitisTarihi = new Date(tarihObj);
    bitisTarihi.setFullYear(bitisTarihi.getFullYear() + 1);

    const { drive } = await getDriveClient();
    const tarihStr = tarihObj.toISOString().slice(0,10).replace(/-/g,'');
    const surum = Math.random().toString(36).slice(2,6).toUpperCase();
    const dosyaAdi = `${tarihStr}-teknik-personel-raporu-vasif-raporu-${surum}${path.extname(req.file.originalname)}`;
    const folderId = await getMisDriveFolder(drive, [mera.il_ad, mera.ilce_ad, mera.mahalle_ad, `${mera.ada||'0'}-${mera.parsel}`, 'Vasıf']);
    const driveData = await driveYukle(drive, folderId, dosyaAdi, req.file.mimetype, req.file.buffer);
    const downloadLink = `https://drive.google.com/uc?export=download&id=${driveData.id}`;

    if (vasif) mera.vasif = vasif;
    mera.vasif_tarih = tarihObj;
    mera.vasif_bitis = bitisTarihi;
    mera.vasif_dosya_id = driveData.id;
    mera.vasif_dosya_link = driveData.webViewLink;

    // Dosyalar sekmesine ekle
    mera.dosyalar.push({
      ad: dosyaAdi,
      kategori: 'Teknik Personel Raporu',
      kaynak: 'vasif',
      drive_file_id: driveData.id,
      drive_web_link: driveData.webViewLink,
      drive_download_link: downloadLink,
      boyut: req.file.size,
      mime_type: req.file.mimetype,
    });

    await mera.save();
    res.json({ success: true, data: { vasif: mera.vasif, vasif_tarih: mera.vasif_tarih, vasif_bitis: mera.vasif_bitis, link: driveData.webViewLink } });
  } catch (err) { next(err); }
};

// ── Tahsis Durumu Dosya Yükleme ───────────────────────────
const tahsisDosyaYukle = async (req, res, next) => {
  try {
    const mera = await Mera.findById(req.params.id);
    if (!mera) return res.status(404).json({ success: false, message: 'Mera bulunamadı' });
    if (!req.file) return res.status(400).json({ success: false, message: 'Dosya seçin' });
    const { tahsis_durumu, tarih } = req.body;
    if (!tarih) return res.status(400).json({ success: false, message: 'Tarih zorunlu' });

    const tarihObj = new Date(tarih);
    const bitisTarihi = new Date(tarihObj);
    bitisTarihi.setFullYear(bitisTarihi.getFullYear() + 5);

    const { drive } = await getDriveClient();
    const tarihStr = tarihObj.toISOString().slice(0,10).replace(/-/g,'');
    const surum = Math.random().toString(36).slice(2,6).toUpperCase();
    const dosyaAdi = `${tarihStr}-tahsis-belgesi-${surum}${path.extname(req.file.originalname)}`;
    const folderId = await getMisDriveFolder(drive, [mera.il_ad, mera.ilce_ad, mera.mahalle_ad, `${mera.ada||'0'}-${mera.parsel}`, 'Tahsis']);
    const driveData = await driveYukle(drive, folderId, dosyaAdi, req.file.mimetype, req.file.buffer);
    const downloadLink = `https://drive.google.com/uc?export=download&id=${driveData.id}`;

    if (tahsis_durumu) mera.tahsis_durumu = tahsis_durumu;
    mera.tahsis_durumu_tarih = tarihObj;
    mera.tahsis_durumu_bitis = bitisTarihi;
    mera.tahsis_durumu_dosya_id = driveData.id;
    mera.tahsis_durumu_dosya_link = driveData.webViewLink;

    // Dosyalar sekmesine ekle
    mera.dosyalar.push({
      ad: dosyaAdi,
      kategori: 'Tahsis Belgesi',
      kaynak: 'tahsis',
      drive_file_id: driveData.id,
      drive_web_link: driveData.webViewLink,
      drive_download_link: downloadLink,
      boyut: req.file.size,
      mime_type: req.file.mimetype,
    });

    await mera.save();
    res.json({ success: true, data: { tahsis_durumu: mera.tahsis_durumu, tarih: mera.tahsis_durumu_tarih, bitis: mera.tahsis_durumu_bitis, link: driveData.webViewLink } });
  } catch (err) { next(err); }
};

// ── İstatistik ────────────────────────────────────────────
const istatistik = async (req, res, next) => {
  try {
    const bugun = new Date();
    const altiAy = new Date(bugun); altiAy.setMonth(altiAy.getMonth() + 6);
    const birYil = new Date(bugun); birYil.setFullYear(birYil.getFullYear() + 1);

    const [toplam, aktif, vasifUyari, tahsisUyari] = await Promise.all([
      Mera.countDocuments({ durum: 'Aktif' }),
      Mera.countDocuments({ durum: 'Aktif' }),
      Mera.countDocuments({ durum: 'Aktif', vasif_bitis: { $exists: true, $lt: altiAy, $gt: bugun } }),
      Mera.countDocuments({ durum: 'Aktif', tahsis_durumu_bitis: { $exists: true, $lt: birYil, $gt: bugun } }),
    ]);

    const aktifMeralar = await Mera.find({ durum: 'Aktif' }).select('tapu_alani_da otlatma');
    const toplamHektar = aktifMeralar.reduce((sum, m) => sum + (m.tapu_alani_da || 0), 0) / 10;
    const toplamBbhb = aktifMeralar.reduce((sum, m) => sum + (m.otlatma?.otlatma_kapasitesi_bbhb || 0), 0);

    const [vasifUyarilar, tahsisUyarilar] = await Promise.all([
      Mera.find({ durum: 'Aktif', vasif_bitis: { $exists: true, $lt: altiAy, $gt: bugun } })
        .select('il_ad ilce_ad mahalle_ad ada parsel vasif vasif_bitis').limit(10),
      Mera.find({ durum: 'Aktif', tahsis_durumu_bitis: { $exists: true, $lt: birYil, $gt: bugun } })
        .select('il_ad ilce_ad mahalle_ad ada parsel tahsis_durumu tahsis_durumu_bitis').limit(10),
    ]);

    res.json({ success: true, data: {
      toplam, aktif, pasif: 0,
      toplam_hektar: parseFloat(toplamHektar.toFixed(2)),
      toplam_bbhb: parseFloat(toplamBbhb.toFixed(2)),
      vasif_uyari: vasifUyari, tahsis_uyari: tahsisUyari,
      vasif_uyarilar: vasifUyarilar || [],
      tahsis_uyarilar: tahsisUyarilar || [],
    }});
  } catch (err) { console.error('[Mera İstatistik Hatası]', err.message); next(err); }
};

module.exports = {
  listele, getById, olustur, guncelle, sil,
  kmlYukle: [upload.single('kml'), kmlYukle],
  kmlGetir,
  notEkle, notGuncelle, notSil,
  dosyaYukle: [upload.single('dosya'), dosyaYukle],
  dosyaSil,
  vasifDosyaYukle: [upload.single('dosya'), vasifDosyaYukle],
  tahsisDosyaYukle: [upload.single('dosya'), tahsisDosyaYukle],
  istatistik,
  pdfRapor,
  hesaplaOtlatma,
};
